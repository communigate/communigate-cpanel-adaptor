/*
 * CodePress regular expressions for Text syntax highlighting
 */

syntax = [
	// do nothing, as expected 
];

CodePress.initialize();

